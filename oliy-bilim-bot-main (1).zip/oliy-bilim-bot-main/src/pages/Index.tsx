import { GraduationCap, Bot, ShieldCheck, Clock, ArrowRight, BarChart3 } from "lucide-react";
import { Link } from "react-router-dom";
import ChatWidget from "@/components/ChatWidget";

const features = [
  {
    icon: Bot,
    title: "AI yordamchi",
    desc: "Sun'iy intellekt orqali 24/7 savollaringizga javob",
  },
  {
    icon: ShieldCheck,
    title: "Ishonchli ma'lumot",
    desc: "Rasmiy ma'lumotlar asosida aniq javoblar",
  },
  {
    icon: Clock,
    title: "Tezkor javob",
    desc: "Bir necha soniyada javob olish imkoniyati",
  },
];

const stats = [
  { value: "50,000+", label: "Savollar" },
  { value: "98%", label: "Javob aniqligi" },
  { value: "24/7", label: "Ishlash vaqti" },
  { value: "150+", label: "Yo'nalishlar" },
];

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <nav className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-40">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg gradient-primary">
              <GraduationCap className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <span className="text-sm font-bold text-foreground">Oliy ta'lim</span>
              <span className="ml-1 text-sm text-muted-foreground">AI</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/admin"
              className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted"
            >
              <BarChart3 className="h-4 w-4" />
              Admin panel
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="gradient-hero relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_hsl(175_50%_40%_/_0.15),_transparent_50%)]" />
        <div className="container mx-auto px-4 py-24 text-center relative">
          <div className="inline-flex items-center gap-2 rounded-full bg-teal/10 border border-teal/20 px-4 py-1.5 text-xs font-medium text-teal-light mb-6">
            <Bot className="h-3.5 w-3.5" />
            Sun'iy intellekt yordamchisi
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground leading-tight mb-4">
            Oliy ta'lim bo'yicha<br />
            <span className="text-teal-light">barcha savollarga javob</span>
          </h1>
          <p className="text-lg text-primary-foreground/70 max-w-xl mx-auto mb-8">
            Universitetga qabul, grant, kontrakt va boshqa masalalar bo'yicha
            AI yordamchidan tezkor javob oling.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                const el = document.querySelector('[aria-label="Chatni ochish"]') as HTMLButtonElement;
                el?.click();
              }}
              className="flex items-center gap-2 rounded-xl gradient-accent px-6 py-3 text-sm font-semibold text-accent-foreground transition-all hover:opacity-90"
            >
              <MessageIcon className="h-4 w-4" />
              Chatni boshlash
            </button>
            <Link
              to="/admin"
              className="flex items-center gap-2 rounded-xl border border-primary-foreground/20 px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-foreground/10"
            >
              Admin panel
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-b border-border bg-card">
        <div className="container mx-auto grid grid-cols-2 md:grid-cols-4 gap-0">
          {stats.map((stat) => (
            <div key={stat.label} className="border-r last:border-r-0 border-border px-6 py-8 text-center">
              <div className="text-2xl font-bold text-primary">{stat.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-3">Qanday ishlaydi?</h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Oddiy va qulay interfeys orqali savolingizga bir necha soniyada javob oling
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 shadow-card transition-all hover:shadow-elevated">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-teal/10">
                <f.icon className="h-6 w-6 text-teal" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            © 2024 Oliy ta'lim vazirligi — AI Chatbot Demo
          </p>
        </div>
      </footer>

      {/* Chat Widget */}
      <ChatWidget />
    </div>
  );
}

function MessageIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}
