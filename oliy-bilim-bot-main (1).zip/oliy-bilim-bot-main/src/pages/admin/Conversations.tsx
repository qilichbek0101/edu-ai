import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Search, MessageSquare, User, Bot, Clock, CheckCircle, AlertTriangle, TrendingUp, Loader2 } from "lucide-react";

interface ConvItem {
  id: string;
  session_id: string;
  status: string;
  created_at: string;
  first_message?: string;
}

interface MsgItem {
  id: string;
  sender_type: string;
  content: string;
  created_at: string;
}

export default function Conversations() {
  const [convs, setConvs] = useState<ConvItem[]>([]);
  const [selected, setSelected] = useState<ConvItem | null>(null);
  const [messages, setMessages] = useState<MsgItem[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase
        .from("conversations")
        .select("id, session_id, status, created_at")
        .order("created_at", { ascending: false });

      if (data) {
        const withMsg: ConvItem[] = [];
        for (const c of data) {
          const { data: msgs } = await supabase
            .from("chat_messages")
            .select("content")
            .eq("conversation_id", c.id)
            .eq("sender_type", "user")
            .order("created_at", { ascending: true })
            .limit(1);
          withMsg.push({ ...c, first_message: msgs?.[0]?.content || "Xabar yo'q" });
        }
        setConvs(withMsg);
        if (withMsg.length > 0) {
          setSelected(withMsg[0]);
        }
      }
      setLoading(false);
    };
    fetch();
  }, []);

  useEffect(() => {
    if (!selected) { setMessages([]); return; }
    const fetch = async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("id, sender_type, content, created_at")
        .eq("conversation_id", selected.id)
        .order("created_at", { ascending: true });
      setMessages(data || []);
    };
    fetch();
  }, [selected?.id]);

  const filtered = convs.filter(
    (c) => c.session_id.includes(search.toLowerCase()) ||
           (c.first_message || "").toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  const statusBadge = (status: string) => {
    if (status === "escalated") return <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium bg-warning/10 text-warning"><AlertTriangle className="h-3 w-3" /> Operator</span>;
    if (status === "resolved") return <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium bg-success/10 text-success"><CheckCircle className="h-3 w-3" /> Hal qilindi</span>;
    return <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium bg-info/10 text-info"><TrendingUp className="h-3 w-3" /> Faol</span>;
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Suhbatlar</h1>
        <p className="text-sm text-muted-foreground mt-1">Foydalanuvchilar bilan chatbot suhbatlari</p>
      </div>

      {convs.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center shadow-card">
          <MessageSquare className="h-10 w-10 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-sm text-muted-foreground">Hali suhbatlar yo'q</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-[360px_1fr] gap-4 h-[calc(100vh-220px)]">
          <div className="rounded-xl border border-border bg-card shadow-card flex flex-col">
            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Qidirish..." className="w-full rounded-lg border border-border bg-muted pl-9 pr-3 py-2 text-sm outline-none focus:border-teal" />
              </div>
            </div>
            <div className="flex-1 overflow-auto divide-y divide-border">
              {filtered.map((c) => (
                <button key={c.id} onClick={() => setSelected(c)} className={`w-full text-left px-4 py-3 transition-colors hover:bg-muted ${selected?.id === c.id ? "bg-muted" : ""}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-foreground">#{c.session_id.slice(0, 8)}</span>
                    {c.status === "escalated" ? <AlertTriangle className="h-3 w-3 text-warning" /> : c.status === "resolved" ? <CheckCircle className="h-3 w-3 text-success" /> : <TrendingUp className="h-3 w-3 text-info" />}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{c.first_message}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString("uz-UZ")}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card shadow-card flex flex-col">
            {selected ? (
              <>
                <div className="border-b border-border px-5 py-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">#{selected.session_id.slice(0, 8)}</h3>
                    <p className="text-xs text-muted-foreground">{new Date(selected.created_at).toLocaleString("uz-UZ")}</p>
                  </div>
                  {statusBadge(selected.status)}
                </div>
                <div className="flex-1 overflow-auto p-5 space-y-3">
                  {messages.map((m) => (
                    <div key={m.id} className={`flex gap-2 ${m.sender_type === "user" ? "flex-row-reverse" : ""}`}>
                      <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${m.sender_type === "user" ? "bg-primary text-primary-foreground" : "bg-teal/10 text-teal"}`}>
                        {m.sender_type === "user" ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                      </div>
                      <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${m.sender_type === "user" ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted text-foreground rounded-bl-md"}`}>
                        {m.content}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Suhbatni tanlang</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
