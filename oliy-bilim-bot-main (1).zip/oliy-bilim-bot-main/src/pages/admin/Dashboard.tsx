import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MessageSquare, CheckCircle, TrendingUp, Users, AlertTriangle, Clock, Loader2 } from "lucide-react";

interface ConvStats {
  total: number;
  resolved: number;
  escalated: number;
  active: number;
}

interface RecentChat {
  id: string;
  session_id: string;
  status: string;
  created_at: string;
  first_message?: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<ConvStats>({ total: 0, resolved: 0, escalated: 0, active: 0 });
  const [recent, setRecent] = useState<RecentChat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: convs } = await supabase.from("conversations").select("id, session_id, status, created_at").order("created_at", { ascending: false });
      
      if (convs) {
        setStats({
          total: convs.length,
          resolved: convs.filter(c => c.status === "resolved").length,
          escalated: convs.filter(c => c.status === "escalated").length,
          active: convs.filter(c => c.status === "active").length,
        });

        const recentConvs = convs.slice(0, 5);
        const recentWithMessages: RecentChat[] = [];

        for (const conv of recentConvs) {
          const { data: msgs } = await supabase
            .from("chat_messages")
            .select("content")
            .eq("conversation_id", conv.id)
            .eq("sender_type", "user")
            .order("created_at", { ascending: true })
            .limit(1);
          
          recentWithMessages.push({
            ...conv,
            first_message: msgs?.[0]?.content || "Xabar yo'q",
          });
        }
        setRecent(recentWithMessages);
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  const resolvedPct = stats.total > 0 ? ((stats.total - stats.escalated) / stats.total * 100).toFixed(1) : "0";

  const statCards = [
    { label: "Jami suhbatlar", value: stats.total.toString(), icon: MessageSquare, color: "text-teal" },
    { label: "Hal qilingan %", value: `${resolvedPct}%`, icon: CheckCircle, color: "text-success" },
    { label: "Escalated", value: stats.escalated.toString(), icon: AlertTriangle, color: "text-warning" },
    { label: "Faol", value: stats.active.toString(), icon: TrendingUp, color: "text-info" },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Boshqaruv paneli</h1>
        <p className="text-sm text-muted-foreground mt-1">Chatbot faoliyati haqida umumiy ma'lumot</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-5 shadow-card">
            <div className="flex items-center justify-between mb-3">
              <s.icon className={`h-5 w-5 ${s.color}`} />
            </div>
            <div className="text-2xl font-bold text-foreground">{s.value}</div>
            <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card shadow-card">
        <div className="border-b border-border px-5 py-4">
          <h2 className="text-base font-semibold text-foreground">So'nggi suhbatlar</h2>
        </div>
        {recent.length === 0 ? (
          <div className="px-5 py-8 text-center text-muted-foreground text-sm">
            Hali suhbatlar yo'q
          </div>
        ) : (
          <div className="divide-y divide-border">
            {recent.map((c) => (
              <div key={c.id} className="flex items-center gap-3 px-5 py-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground text-xs font-semibold">
                  {c.session_id.slice(0, 4)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{c.first_message}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString("uz-UZ")}</span>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${
                  c.status === "escalated" ? "bg-warning/10 text-warning" : c.status === "resolved" ? "bg-success/10 text-success" : "bg-info/10 text-info"
                }`}>
                  {c.status === "escalated" ? <><AlertTriangle className="h-3 w-3" /> Operator</> :
                   c.status === "resolved" ? <><CheckCircle className="h-3 w-3" /> Hal qilindi</> :
                   <><TrendingUp className="h-3 w-3" /> Faol</>}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
