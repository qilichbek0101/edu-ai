import { Save, Globe, Bell, Shield, Palette } from "lucide-react";

export default function Settings() {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Sozlamalar</h1>
        <p className="text-sm text-muted-foreground mt-1">Chatbot sozlamalarini boshqaring</p>
      </div>

      {/* General */}
      <div className="rounded-xl border border-border bg-card shadow-card">
        <div className="border-b border-border px-5 py-4 flex items-center gap-3">
          <Globe className="h-4 w-4 text-teal" />
          <h2 className="text-sm font-semibold text-foreground">Umumiy sozlamalar</h2>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Chatbot nomi</label>
            <input defaultValue="Oliy ta'lim yordamchisi" className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm outline-none focus:border-teal" />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Salomlashish xabari</label>
            <textarea defaultValue="Assalomu alaykum! Oliy ta'lim bo'yicha savollaringizni yozing." rows={3} className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm outline-none focus:border-teal resize-none" />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Til</label>
            <select defaultValue="uz" className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm outline-none focus:border-teal">
              <option value="uz">O'zbek tili</option>
              <option value="ru">Rus tili</option>
              <option value="en">Ingliz tili</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="rounded-xl border border-border bg-card shadow-card">
        <div className="border-b border-border px-5 py-4 flex items-center gap-3">
          <Bell className="h-4 w-4 text-teal" />
          <h2 className="text-sm font-semibold text-foreground">Bildirishnomalar</h2>
        </div>
        <div className="p-5 space-y-4">
          {[
            { label: "Operator chaqirilganda xabar berish", defaultChecked: true },
            { label: "Yangi suhbat boshlanganda xabar berish", defaultChecked: false },
            { label: "Kunlik hisobot yuborish", defaultChecked: true },
          ].map((item) => (
            <label key={item.label} className="flex items-center justify-between cursor-pointer">
              <span className="text-sm text-foreground">{item.label}</span>
              <div className="relative">
                <input type="checkbox" defaultChecked={item.defaultChecked} className="peer sr-only" />
                <div className="h-6 w-11 rounded-full bg-muted transition-colors peer-checked:bg-teal" />
                <div className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-card shadow transition-transform peer-checked:translate-x-5" />
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Security */}
      <div className="rounded-xl border border-border bg-card shadow-card">
        <div className="border-b border-border px-5 py-4 flex items-center gap-3">
          <Shield className="h-4 w-4 text-teal" />
          <h2 className="text-sm font-semibold text-foreground">Xavfsizlik</h2>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">API kalit</label>
            <input type="password" defaultValue="sk-demo-xxxxx" className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm outline-none focus:border-teal" />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Maksimal kunlik so'rovlar</label>
            <input type="number" defaultValue={10000} className="w-full rounded-lg border border-border bg-muted px-3 py-2.5 text-sm outline-none focus:border-teal" />
          </div>
        </div>
      </div>

      <button className="flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:bg-navy-light">
        <Save className="h-4 w-4" />
        Saqlash
      </button>
    </div>
  );
}
