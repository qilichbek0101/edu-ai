import { useState } from "react";
import { Plus, GripVertical, Edit2, Trash2, ChevronDown, ChevronRight, HelpCircle } from "lucide-react";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  isOpen: boolean;
}

const initialFAQ: FAQItem[] = [
  { id: "f1", question: "Universitetga qanday kirish mumkin?", answer: "Universitetga kirish uchun DTM orqali test topshirishingiz, kerakli hujjatlarni yig'ishingiz va onlayn ariza topshirishingiz kerak.", isOpen: false },
  { id: "f2", question: "Grant va kontrakt o'rtasidagi farq nima?", answer: "Grant — davlat hisobidan bepul o'qish. Kontrakt — o'z hisobingizdan to'lab o'qish. Grant olish uchun test imtihonida yuqori ball to'plash kerak.", isOpen: false },
  { id: "f3", question: "Qabul muddatlari qachon?", answer: "Ariza qabuli odatda iyun-iyul oylarida, test imtihonlari esa avgustda o'tkaziladi. Aniq sanalar DTM tomonidan e'lon qilinadi.", isOpen: false },
  { id: "f4", question: "Sirtqi ta'limga qabul bormi?", answer: "Ha, sirtqi (masofaviy) ta'lim 150+ yo'nalishda mavjud. Yosh chegarasi yo'q, ariza onlayn topshiriladi.", isOpen: false },
  { id: "f5", question: "Chatbot qanday ishlaydi?", answer: "Chatbot sun'iy intellekt texnologiyasi asosida ishlaydi. U foydalanuvchi savollarini tahlil qilib, bilim bazasidan mos javobni topadi.", isOpen: false },
  { id: "f6", question: "Operator bilan qanday bog'lanish mumkin?", answer: "Agar chatbot javob bera olmasa, 'Operatorga yuborish' tugmasini bosing. Operator ish vaqtida (9:00-18:00) javob beradi.", isOpen: false },
];

export default function FAQ() {
  const [faqs, setFaqs] = useState(initialFAQ);

  const toggleFAQ = (id: string) => {
    setFaqs((prev) => prev.map((f) => f.id === id ? { ...f, isOpen: !f.isOpen } : f));
  };

  const deleteFAQ = (id: string) => {
    setFaqs((prev) => prev.filter((f) => f.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">FAQ boshqaruvi</h1>
          <p className="text-sm text-muted-foreground mt-1">Tez-tez so'raladigan savollarni boshqaring</p>
        </div>
        <button className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:bg-navy-light">
          <Plus className="h-4 w-4" />
          Yangi FAQ
        </button>
      </div>

      <div className="space-y-3">
        {faqs.map((faq) => (
          <div key={faq.id} className="rounded-xl border border-border bg-card shadow-card overflow-hidden">
            <div className="flex items-center gap-3 px-5 py-4">
              <GripVertical className="h-4 w-4 text-muted-foreground/40 cursor-grab" />
              <button onClick={() => toggleFAQ(faq.id)} className="flex-1 text-left flex items-center gap-3">
                {faq.isOpen ? (
                  <ChevronDown className="h-4 w-4 text-teal shrink-0" />
                ) : (
                  <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                )}
                <span className="text-sm font-medium text-foreground">{faq.question}</span>
              </button>
              <div className="flex gap-1 shrink-0">
                <button className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground">
                  <Edit2 className="h-3.5 w-3.5" />
                </button>
                <button onClick={() => deleteFAQ(faq.id)} className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
            {faq.isOpen && (
              <div className="border-t border-border bg-muted/30 px-5 py-4 pl-14">
                <p className="text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {faqs.length === 0 && (
        <div className="text-center py-12">
          <HelpCircle className="h-10 w-10 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-sm text-muted-foreground">FAQ mavjud emas</p>
        </div>
      )}
    </div>
  );
}
