import { useState } from "react";
import { Search, Edit2, Trash2, Plus, BookOpen } from "lucide-react";
import { knowledgeBase, categories, type QAPair } from "@/data/knowledgeBase";

export default function KnowledgeBasePage() {
  const [items, setItems] = useState<QAPair[]>(knowledgeBase);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [editingId, setEditingId] = useState<string | null>(null);

  const filtered = items.filter((item) => {
    const matchSearch = item.question.toLowerCase().includes(search.toLowerCase()) ||
                        item.answer.toLowerCase().includes(search.toLowerCase());
    const matchCat = selectedCategory === "all" || item.category === selectedCategory;
    return matchSearch && matchCat;
  });

  const handleDelete = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Bilim bazasi</h1>
          <p className="text-sm text-muted-foreground mt-1">Chatbot javob beradigan savollar va javoblar</p>
        </div>
        <button className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-navy-light">
          <Plus className="h-4 w-4" />
          Yangi qo'shish
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Savollarni qidirish..."
            className="w-full rounded-xl border border-border bg-card pl-9 pr-3 py-2.5 text-sm outline-none focus:border-teal focus:ring-1 focus:ring-teal"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
              selectedCategory === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            Barchasi ({items.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                selectedCategory === cat.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Items */}
      <div className="space-y-3">
        {filtered.map((item) => {
          const cat = categories.find((c) => c.id === item.category);
          return (
            <div key={item.id} className="rounded-xl border border-border bg-card p-5 shadow-card transition-all hover:shadow-elevated">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm">{cat?.icon}</span>
                    <span className="text-xs font-medium text-teal bg-teal/10 rounded-full px-2 py-0.5">
                      {cat?.name}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-foreground mb-2">{item.question}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 whitespace-pre-line">
                    {item.answer.slice(0, 150)}...
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {item.keywords.slice(0, 5).map((kw) => (
                      <span key={kw} className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <button className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
                    <Edit2 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-10 w-10 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-sm text-muted-foreground">Natija topilmadi</p>
        </div>
      )}
    </div>
  );
}
