import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { GraduationCap, Loader2, AlertCircle } from "lucide-react";

export default function Login() {
  const { signIn, isAdmin, isLoading, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (user && isAdmin) {
    return <Navigate to="/admin" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const { error } = await signIn(email, password);
    if (error) {
      setError("Email yoki parol noto'g'ri");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center gradient-hero px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-teal/20 backdrop-blur-sm mb-4">
            <GraduationCap className="h-7 w-7 text-teal-light" />
          </div>
          <h1 className="text-2xl font-bold text-primary-foreground">Admin kirish</h1>
          <p className="text-sm text-primary-foreground/60 mt-1">
            Oliy ta'lim chatbot boshqaruvi
          </p>
        </div>

        <form onSubmit={handleSubmit} className="rounded-2xl border border-border/10 bg-card p-6 shadow-elevated space-y-4">
          {error && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2.5 text-sm text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {user && !isAdmin && (
            <div className="flex items-center gap-2 rounded-lg bg-warning/10 px-3 py-2.5 text-sm text-warning">
              <AlertCircle className="h-4 w-4 shrink-0" />
              Sizda admin huquqi yo'q
            </div>
          )}

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@edu.uz"
              required
              className="w-full rounded-xl border border-border bg-muted px-4 py-2.5 text-sm outline-none focus:border-teal focus:ring-1 focus:ring-teal"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground block mb-1.5">Parol</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full rounded-xl border border-border bg-muted px-4 py-2.5 text-sm outline-none focus:border-teal focus:ring-1 focus:ring-teal"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-navy-light disabled:opacity-60"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            Kirish
          </button>
        </form>
      </div>
    </div>
  );
}
