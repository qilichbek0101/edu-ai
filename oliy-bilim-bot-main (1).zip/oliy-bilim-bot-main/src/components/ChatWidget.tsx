import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, User, Bot, ArrowRight } from "lucide-react";
import { findAnswer } from "@/data/knowledgeBase";
import { supabase } from "@/integrations/supabase/client";
import ReactMarkdown from "react-markdown";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
  showEscalation?: boolean;
}

const WELCOME_MESSAGE: Message = {
  id: "welcome",
  text: "Assalomu alaykum! 👋\n\nMen Oliy ta'lim vazirligi sun'iy intellekt yordamchisiman. Universitetga qabul, grant, kontrakt va boshqa savollaringizga javob beraman.\n\nSavolingizni yozing!",
  sender: "bot",
  timestamp: new Date(),
};

const QUICK_QUESTIONS = [
  "Grant qanday olinadi?",
  "Kontrakt narxi qancha?",
  "Qanday hujjatlar kerak?",
  "Qabul muddati qachon?",
];

function getSessionId() {
  let id = sessionStorage.getItem("chat_session_id");
  if (!id) {
    id = crypto.randomUUID();
    sessionStorage.setItem("chat_session_id", id);
  }
  return id;
}

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    if (isOpen) inputRef.current?.focus();
  }, [isOpen]);

  const ensureConversation = async () => {
    if (conversationId) return conversationId;
    const sessionId = getSessionId();
    const { data } = await supabase
      .from("conversations")
      .insert({ session_id: sessionId })
      .select("id")
      .single();
    if (data) {
      setConversationId(data.id);
      return data.id;
    }
    return null;
  };

  const saveMessage = async (convId: string, content: string, senderType: "user" | "bot") => {
    await supabase.from("chat_messages").insert({
      conversation_id: convId,
      content,
      sender_type: senderType,
    });
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: text.trim(),
      sender: "user",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    const convId = await ensureConversation();
    if (convId) {
      await saveMessage(convId, text.trim(), "user");
    }

    const delay = 800 + Math.random() * 1200;
    setTimeout(async () => {
      const result = findAnswer(text);
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: result.answer,
        sender: "bot",
        timestamp: new Date(),
        showEscalation: !result.matched,
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);

      if (convId) {
        await saveMessage(convId, result.answer, "bot");
        if (!result.matched) {
          await supabase.from("conversations").update({ status: "escalated" }).eq("id", convId);
        }
      }
    }, delay);
  };

  const handleEscalate = async () => {
    const escalationText = "✅ Sizning so'rovingiz operatorga yo'natirildi. Operator tez orada siz bilan bog'lanadi.\n\n📞 Qo'shimcha: +998 71 203-00-99\n📧 Email: info@edu.uz";
    const msg: Message = {
      id: Date.now().toString(),
      text: escalationText,
      sender: "bot",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, msg]);
    if (conversationId) {
      await saveMessage(conversationId, escalationText, "bot");
      await supabase.from("conversations").update({ status: "escalated" }).eq("id", conversationId);
    }
  };

  return (
    <>
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 flex h-16 w-16 items-center justify-center rounded-full gradient-primary shadow-chat transition-all hover:scale-105 active:scale-95"
          aria-label="Chatni ochish"
        >
          <MessageCircle className="h-7 w-7 text-primary-foreground" />
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-teal text-[10px] font-bold text-accent-foreground">
            1
          </span>
        </button>
      )}

      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 flex h-[600px] w-[400px] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-chat animate-slide-in">
          <div className="gradient-hero flex items-center gap-3 px-5 py-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal/20 backdrop-blur-sm">
              <Bot className="h-5 w-5 text-teal-light" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-primary-foreground">Oliy ta'lim yordamchisi</h3>
              <p className="text-xs text-primary-foreground/70">AI chatbot • Onlayn</p>
            </div>
            <button onClick={() => setIsOpen(false)} className="rounded-lg p-1.5 text-primary-foreground/70 transition-colors hover:bg-primary-foreground/10 hover:text-primary-foreground">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-2 animate-fade-in-up ${msg.sender === "user" ? "flex-row-reverse" : ""}`}>
                <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${msg.sender === "user" ? "bg-primary text-primary-foreground" : "bg-teal/10 text-teal"}`}>
                  {msg.sender === "user" ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                </div>
                <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${msg.sender === "user" ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted text-foreground rounded-bl-md"}`}>
                  <div className="prose prose-sm max-w-none dark:prose-invert [&>p]:my-1 [&>ul]:my-1 [&>ol]:my-1">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                  {msg.showEscalation && (
                    <button onClick={handleEscalate} className="mt-3 flex items-center gap-2 rounded-lg bg-teal px-3 py-2 text-xs font-medium text-accent-foreground transition-colors hover:bg-teal-dark">
                      <ArrowRight className="h-3.5 w-3.5" />
                      Operatorga yuborish
                    </button>
                  )}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-2 animate-fade-in-up">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-teal/10 text-teal">
                  <Bot className="h-3.5 w-3.5" />
                </div>
                <div className="rounded-2xl rounded-bl-md bg-muted px-4 py-3">
                  <div className="flex gap-1.5">
                    <span className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
                    <span className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
                    <span className="typing-dot h-2 w-2 rounded-full bg-muted-foreground" />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {messages.length <= 1 && (
            <div className="flex flex-wrap gap-2 border-t border-border px-4 py-3">
              {QUICK_QUESTIONS.map((q) => (
                <button key={q} onClick={() => sendMessage(q)} className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-muted hover:border-teal">
                  {q}
                </button>
              ))}
            </div>
          )}

          <div className="border-t border-border p-3">
            <form onSubmit={(e) => { e.preventDefault(); sendMessage(input); }} className="flex items-center gap-2">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Savolingizni yozing..."
                className="flex-1 rounded-xl border border-border bg-muted px-4 py-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-teal focus:ring-1 focus:ring-teal"
              />
              <button type="submit" disabled={!input.trim() || isTyping} className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all hover:bg-navy-light disabled:opacity-40">
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
