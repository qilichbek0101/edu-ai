export interface QAPair {
  id: string;
  question: string;
  answer: string;
  keywords: string[];
  category: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export const categories: Category[] = [
  { id: "qabul", name: "Qabul (Kirish)", icon: "🎓", description: "Universitetga qabul jarayoni" },
  { id: "grant", name: "Grant va kontrakt", icon: "💰", description: "Grant va kontrakt to'lovlari" },
  { id: "hujjatlar", name: "Hujjatlar", icon: "📄", description: "Kerakli hujjatlar ro'yxati" },
  { id: "muddatlar", name: "Muddatlar", icon: "📅", description: "Muhim sanalar va muddatlar" },
  { id: "imtihonlar", name: "Imtihonlar", icon: "📝", description: "Test va imtihonlar haqida" },
];

export const knowledgeBase: QAPair[] = [
  // === QABUL ===
  {
    id: "q1",
    question: "Universitetga qanday kirish mumkin?",
    answer: "Universitetga kirish uchun quyidagi bosqichlarni bajarishingiz kerak:\n\n1️⃣ **Onlayn ariza topshirish** — my.uzedu.uz portalida ro'yxatdan o'ting\n2️⃣ **Hujjatlarni tayyorlash** — pasport, attestat, 3x4 rasm\n3️⃣ **Test imtihoniga yozilish** — DTM orqali\n4️⃣ **Imtihon topshirish** — belgilangan sanada\n5️⃣ **Natijalarni kutish** — 10 kun ichida e'lon qilinadi",
    keywords: ["kirish", "qabul", "universitetga", "o'qishga", "kirmoq", "qanday"],
    category: "qabul",
  },
  {
    id: "q2",
    question: "Qabul kvotasi qancha?",
    answer: "2024/2025 o'quv yili uchun kvotalar:\n\n• **Bakalavriat grant** — 58,763 ta o'rin\n• **Bakalavriat kontrakt** — cheklanmagan\n• **Magistratura grant** — 15,200 ta o'rin\n• **Sirtqi ta'lim** — 45,000+ o'rin\n\nHar bir yo'nalish bo'yicha alohida kvota belgilanadi.",
    keywords: ["kvota", "o'rin", "nechta", "joy", "qabul"],
    category: "qabul",
  },
  {
    id: "q3",
    question: "Qabul qachon boshlanadi?",
    answer: "2024 yil qabul jadvali:\n\n📅 **Ariza qabuli**: 15-iyun — 15-iyul\n📅 **Hujjat topshirish**: 20-iyun — 20-iyul\n📅 **Test imtihonlari**: 1-avgust — 20-avgust\n📅 **Natijalar e'loni**: 25-avgust\n\nAniq sanalar DTM tomonidan e'lon qilinadi.",
    keywords: ["qabul", "boshlanadi", "qachon", "muddati", "sana", "ariza"],
    category: "qabul",
  },
  {
    id: "q4",
    question: "Sirtqi ta'limga qabul qanday?",
    answer: "Sirtqi (masofaviy) ta'limga qabul:\n\n• **Yosh chegarasi yo'q** — istalgan yosh\n• **Ariza** — onlayn topshiriladi\n• **Imtihon** — test shakilda\n• **Narxi** — kunduzigiga nisbatan arzonroq\n• **Muddati** — 5 yil (bakalavriat)\n\nSirtqi ta'lim 150+ yo'nalishda mavjud.",
    keywords: ["sirtqi", "masofaviy", "zaochno", "sirtdan"],
    category: "qabul",
  },
  {
    id: "q5",
    question: "Chet ellik talabalar qanday qabul qilinadi?",
    answer: "Chet el fuqarolari uchun:\n\n• **O'zbek yoki rus tilida** imtihon topshirishi mumkin\n• **Pasport va viza** talab qilinadi\n• **Hujjatlar tarjimasi** — notarial tasdiqlangan\n• **Tibbiy ma'lumotnoma** kerak\n• **Kontrakt asosida** o'qish imkoniyati\n\nBatafsil: edu.uz/international",
    keywords: ["chet", "xorijiy", "foreign", "international", "fuqaro"],
    category: "qabul",
  },

  // === GRANT VA KONTRAKT ===
  {
    id: "g1",
    question: "Grant qanday olinadi?",
    answer: "Davlat grantini olish uchun:\n\n🏆 **Yuqori ball** — test imtihonida eng yuqori natija\n📊 **Reyting asosida** — grantlar reyting bo'yicha taqsimlanadi\n📋 **Hujjatlar to'liq** bo'lishi shart\n\n**Grant egalari uchun:**\n• O'qish bepul\n• Stipendiya beriladi (900,000 - 1,200,000 so'm/oy)\n• Yotoqxonada joy ajratiladi\n\nGrant olish uchun o'rtacha 150+ ball kerak.",
    keywords: ["grant", "bepul", "stipendiya", "davlat", "olinadi", "olish"],
    category: "grant",
  },
  {
    id: "g2",
    question: "Kontrakt narxi qancha?",
    answer: "2024/2025 yil kontrakt narxlari (yillik):\n\n💰 **Kunduzgi:**\n• Ijtimoiy-gumanitar — 12,800,000 so'm\n• Texnik — 14,400,000 so'm\n• Tibbiyot — 22,000,000 so'm\n• IT va dasturlash — 16,000,000 so'm\n\n💰 **Sirtqi:**\n• O'rtacha — 6,400,000 so'm\n\n💰 **Magistratura:**\n• 16,000,000 — 25,000,000 so'm\n\nNarxlar universitetga qarab farq qiladi.",
    keywords: ["kontrakt", "narx", "qancha", "to'lov", "pul", "narxi", "summa"],
    category: "grant",
  },
  {
    id: "g3",
    question: "Kontrakt to'lovini bo'lib to'lash mumkinmi?",
    answer: "Ha, kontrakt to'lovini bo'lib to'lash mumkin:\n\n✅ **2 ta qismda** — har semestrda\n✅ **Oylik to'lov** — bank orqali\n✅ **Ta'lim krediti** — bankdan kredit olish imkoniyati\n\n**Ta'lim krediti shartlari:**\n• Foiz stavkasi: yillik 14-18%\n• Muddat: 3-5 yil\n• Kafil talab qilinadi\n\nTo'lov muddati o'tkazilsa, jarima 0.1%/kun.",
    keywords: ["bo'lib", "to'lash", "kredit", "nasiya", "qism", "to'lov"],
    category: "grant",
  },
  {
    id: "g4",
    question: "Grantdan kontraktga o'tish mumkinmi?",
    answer: "⚠️ Grant o'rnini yo'qotish holatlari:\n\n• Akademik qarzdorlik (2+ fan bo'yicha)\n• Intizomiy jazo\n• O'qishni uzluksiz 30+ kun sababsiz qoldirish\n\nBu holda talaba **kontrakt asosiga** o'tkaziladi.\n\nAksincha, kontraktdan grantga o'tish ham mumkin — agar bo'sh grant o'rni bo'lsa va GPA yuqori bo'lsa.",
    keywords: ["grantdan", "kontraktga", "o'tish", "yo'qotish", "o'zgartirish"],
    category: "grant",
  },
  {
    id: "g5",
    question: "Stipendiya miqdori qancha?",
    answer: "2024 yil uchun stipendiya miqdorlari:\n\n📌 **Oddiy stipendiya**: 900,000 so'm/oy\n📌 **Yuqori ball uchun**: 1,200,000 so'm/oy\n📌 **Prezident stipendiyasi**: 2,500,000 so'm/oy\n📌 **Magistratura**: 1,500,000 so'm/oy\n\nStipendiya faqat **grant asosida** o'qiyotganlarga beriladi.",
    keywords: ["stipendiya", "miqdor", "oylik", "pul"],
    category: "grant",
  },

  // === HUJJATLAR ===
  {
    id: "h1",
    question: "Qabul uchun qanday hujjatlar kerak?",
    answer: "Bakalavriatga kerakli hujjatlar:\n\n📁 **Asosiy:**\n1. Pasport nusxasi\n2. Attestat (diplom) asl nusxasi\n3. 3x4 rasm (6 dona)\n4. PINFL ma'lumotlari\n\n📁 **Qo'shimcha:**\n5. Tibbiy ma'lumotnoma (086-shakl)\n6. Harbiy hisob guvohnomasi (yigitlar)\n7. Imtiyozli hujjatlar (mavjud bo'lsa)\n\nBarcha hujjatlar **asl nusxada** topshiriladi.",
    keywords: ["hujjat", "hujjatlar", "kerak", "nima", "ro'yxat", "ro'yxati", "talab"],
    category: "hujjatlar",
  },
  {
    id: "h2",
    question: "Magistratura uchun qanday hujjatlar kerak?",
    answer: "Magistraturaga kerakli hujjatlar:\n\n📁 **Asosiy:**\n1. Pasport nusxasi\n2. Bakalavriat diplomi + ilova\n3. 3x4 rasm (4 dona)\n4. Ish joyidan ma'lumotnoma\n\n📁 **Qo'shimcha:**\n5. Ilmiy maqolalar ro'yxati\n6. Xorijiy til sertifikati (IELTS/CEFR)\n7. Tibbiy ma'lumotnoma\n\nChet tili sertifikati **B2 darajada** bo'lishi kerak.",
    keywords: ["magistratura", "magistr", "hujjat", "diplom"],
    category: "hujjatlar",
  },
  {
    id: "h3",
    question: "Hujjatlarni onlayn topshirish mumkinmi?",
    answer: "Ha, hujjatlarni **onlayn topshirish** mumkin:\n\n🌐 **Portal**: my.uzedu.uz\n📱 **Mobil ilova**: DTM — qabul\n\n**Onlayn topshirish bosqichlari:**\n1. Ro'yxatdan o'tish (PINFL orqali)\n2. Shaxsiy ma'lumotlarni kiritish\n3. Hujjatlar rasmini yuklash\n4. Yo'nalish tanlash (5 tagacha)\n5. To'lovni amalga oshirish\n\nOnlayn ariza to'lovi: **95,000 so'm**",
    keywords: ["onlayn", "online", "internet", "portal", "elektron"],
    category: "hujjatlar",
  },
  {
    id: "h4",
    question: "Attestat yo'qolsa nima qilish kerak?",
    answer: "Attestat yo'qolgan bo'lsa:\n\n1. **Maktabga murojaat** qiling — dublikat olish uchun\n2. **Gazeta e'loni** — yo'qolganligi haqida\n3. **IIB ma'lumotnoma** — yo'qotish haqida\n\nDublikat olish **15 ish kuni** ichida amalga oshiriladi.\n\n⚠️ Dublikat bilan ham qabul imtihonida ishtirok etish mumkin.",
    keywords: ["attestat", "yo'qolsa", "yo'qol", "dublikat", "qayta"],
    category: "hujjatlar",
  },
  {
    id: "h5",
    question: "Tibbiy ko'rik qayerda o'tiladi?",
    answer: "Tibbiy ko'rik (086-shakl) uchun:\n\n🏥 **Davlat poliklinikasi** — yashash joyingiz bo'yicha\n🏥 **Xususiy klinikalar** — litsenziyaga ega\n\n**Ko'rikdan o'tish kerak:**\n• Terapevt\n• Ftiziattr\n• Dermatolog\n• Narkolog\n• Psixiatr\n\nKo'rik narxi: **50,000 — 150,000 so'm**\nMuddati: **6 oy** amal qiladi.",
    keywords: ["tibbiy", "ko'rik", "086", "vrach", "doktor", "salomatlik"],
    category: "hujjatlar",
  },

  // === MUDDATLAR ===
  {
    id: "m1",
    question: "Qabul muddati qachon?",
    answer: "2024 yil uchun muhim sanalar:\n\n📅 **Ariza qabuli boshlanishi**: 15 iyun\n📅 **Ariza qabuli tugashi**: 15 iyul\n📅 **Test imtihonlari**: 1–20 avgust\n📅 **Natijalar e'lon qilinishi**: 25 avgust\n📅 **Shartnoma tuzish**: 1–10 sentyabr\n📅 **O'quv yili boshlanishi**: 11 sentyabr\n\n⚠️ Muddatlar o'zgarishi mumkin — dtm.uz ni kuzatib boring.",
    keywords: ["muddat", "muddati", "qachon", "sana", "vaqt", "kalendar"],
    category: "muddatlar",
  },
  {
    id: "m2",
    question: "Magistratura hujjat topshirish muddati qachon?",
    answer: "Magistratura qabul muddatlari:\n\n📅 **Ariza va hujjat qabuli**: 1 iyul — 1 avgust\n📅 **Chet tili imtihoni**: 5–15 avgust\n📅 **Mutaxassislik imtihoni**: 16–25 avgust\n📅 **Natijalar**: 1 sentyabr\n📅 **O'quv boshlanishi**: 15 sentyabr\n\n⚠️ Chet tili sertifikati bo'lsa, imtihondan ozod.",
    keywords: ["magistratura", "magistr", "muddat", "qachon", "topshirish"],
    category: "muddatlar",
  },
  {
    id: "m3",
    question: "Transfer qachon bo'ladi?",
    answer: "Boshqa universitetga **o'tkazma (transfer)** muddatlari:\n\n📅 **Qishki transfer**: 15–30 yanvar\n📅 **Yozgi transfer**: 15 iyun — 15 iyul\n\n**Shartlar:**\n• Akademik qarzdorlik yo'q\n• GPA 3.0+ (grant uchun)\n• Qabul qiluvchi universitet roziligi\n• Fan farqlari 4 tadan ko'p bo'lmasligi kerak",
    keywords: ["transfer", "o'tkazma", "boshqa", "universitetga", "ko'chirish"],
    category: "muddatlar",
  },
  {
    id: "m4",
    question: "Stipendiya qachon beriladi?",
    answer: "Stipendiya to'lov jadvali:\n\n💵 Har oyning **15–20 sanalari** orasida\n💵 Bank kartasiga o'tkaziladi\n💵 Birinchi stipendiya — **oktyabr oyida**\n\n⚠️ Akademik qarzdorlik bo'lsa, stipendiya **to'xtatiladi**.",
    keywords: ["stipendiya", "qachon", "beriladi", "oy", "to'lov"],
    category: "muddatlar",
  },
  {
    id: "m5",
    question: "Akademik ta'til qachon olinadi?",
    answer: "Akademik ta'til olish:\n\n📅 **Murojaat**: istalgan vaqtda\n📅 **Ko'rib chiqish**: 10 ish kuni\n📅 **Muddat**: 1 yilgacha\n\n**Sabablari:**\n• Sog'liq holati (tibbiy ma'lumotnoma)\n• Oilaviy sharoit\n• Moliyaviy qiyinchilik\n\nAkademdan qaytish — **keyingi semestr boshida**.",
    keywords: ["akademik", "ta'til", "akadem", "to'xtatish", "dam"],
    category: "muddatlar",
  },

  // === IMTIHONLAR ===
  {
    id: "i1",
    question: "Test imtihoni qanday o'tkaziladi?",
    answer: "DTM test imtihoni tartibi:\n\n📝 **Fanlar soni**: 5 ta fan\n⏱️ **Vaqt**: 3 soat 30 daqiqa\n📊 **Savollar**: 90 ta (har biri 3.5 ball)\n🏆 **Maksimal ball**: 315\n\n**Imtihon kuni:**\n1. Pasport bilan kelish\n2. Telefon, soat **taqiqlangan**\n3. Javoblar OMR varaqaga belgilanadi\n4. Natija 3 kun ichida e'lon qilinadi\n\n⚠️ Noqonuniy harakatlar uchun — **5 yil davomida qayta topshirish taqiqlanadi**.",
    keywords: ["test", "imtihon", "dtm", "sinov", "savol", "ball"],
    category: "imtihonlar",
  },
  {
    id: "i2",
    question: "Qaysi fanlardan imtihon bo'ladi?",
    answer: "Yo'nalishga qarab fanlar:\n\n🔬 **Texnik**: Matematika, Fizika, Ona tili\n🧪 **Tibbiyot**: Biologiya, Kimyo, Ona tili\n📚 **Gumanitar**: Tarix, Ona tili, Adabiyot\n💻 **IT**: Matematika, Fizika, Ingliz tili\n🏛️ **Huquq**: Tarix, Ona tili, Matematika\n💰 **Iqtisodiyot**: Matematika, Chet tili, Ona tili\n\nHar bir yo'nalish uchun 3 ta **majburiy** va 2 ta **tanlov** fani.",
    keywords: ["fan", "fanlar", "qaysi", "predmet", "yo'nalish"],
    category: "imtihonlar",
  },
  {
    id: "i3",
    question: "O'tish bali qancha?",
    answer: "2024 yil uchun o'tish ballari (taxminiy):\n\n🏆 **Grant uchun:**\n• Tibbiyot — 189+ ball\n• IT — 175+ ball\n• Texnik — 155+ ball\n• Gumanitar — 140+ ball\n\n📋 **Kontrakt uchun:**\n• Minimal o'tish bali — 56 ball (30%)\n\n⚠️ O'tish ballari har yili o'zgaradi va raqobatga bog'liq.",
    keywords: ["o'tish", "bal", "ball", "minimal", "qancha", "nechta"],
    category: "imtihonlar",
  },
  {
    id: "i4",
    question: "Imtihon natijasiga shikoyat qilish mumkinmi?",
    answer: "Ha, **apellyatsiya** berish mumkin:\n\n📋 **Muddat**: Natija e'lon qilinganidan 3 kun ichida\n📋 **Ariza**: DTM ga yozma murojaat\n📋 **Ko'rib chiqish**: 5 ish kuni\n📋 **To'lov**: Bepul\n\n**Apellyatsiya natijasi:**\n• Ball oshishi mumkin\n• Ball kamayishi mumkin\n• O'zgarmasdan qolishi mumkin\n\nQaror yakuniy hisoblanadi.",
    keywords: ["shikoyat", "apellyatsiya", "norozilik", "qayta", "tekshirish", "natija"],
    category: "imtihonlar",
  },
  {
    id: "i5",
    question: "IELTS sertifikati kerakmi?",
    answer: "Chet tili sertifikati talabi:\n\n🎓 **Bakalavriat**: Shart emas (lekin qo'shimcha ball beradi)\n🎓 **Magistratura**: **Majburiy** (B2 daraja)\n\n**Qabul qilinadigan sertifikatlar:**\n• IELTS — 5.5+\n• CEFR — B2+\n• TOEFL — 72+\n\n**Sertifikatsiz**: DTM chet tili imtihonidan o'tish kerak\n\n💡 Sertifikat **2 yil** ichida olingan bo'lishi kerak.",
    keywords: ["ielts", "sertifikat", "ingliz", "chet", "tili", "toefl", "cefr"],
    category: "imtihonlar",
  },
];

export function findAnswer(query: string): { answer: string; matched: boolean; category?: string } {
  const normalizedQuery = query.toLowerCase().trim();
  
  // Score each Q&A pair
  let bestMatch: QAPair | null = null;
  let bestScore = 0;

  for (const qa of knowledgeBase) {
    let score = 0;
    for (const keyword of qa.keywords) {
      if (normalizedQuery.includes(keyword.toLowerCase())) {
        score += keyword.length; // longer keyword matches = higher score
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = qa;
    }
  }

  if (bestMatch && bestScore >= 3) {
    return { answer: bestMatch.answer, matched: true, category: bestMatch.category };
  }

  return {
    answer: "Kechirasiz, bu savol bo'yicha aniq javob topa olmadim. Sizni mutaxassis operatorga yo'naltiraman.",
    matched: false,
  };
}
